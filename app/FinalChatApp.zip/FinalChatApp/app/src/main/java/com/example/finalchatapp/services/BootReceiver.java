package com.example.finalchatapp.services;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

/**
 * Receiver to start notification services when the device boots up
 */
public class BootReceiver extends BroadcastReceiver {
    private static final String TAG = "BootReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction() != null &&
                intent.getAction().equals(Intent.ACTION_BOOT_COMPLETED)) {
            Log.d(TAG, "Boot completed - initializing notification services");

            // Schedule periodic notification checks
            NotificationService.scheduleNotifications(context);

            // Start real-time message listeners
            MessageListener.startMessageListeners(context);
        }
    }
}