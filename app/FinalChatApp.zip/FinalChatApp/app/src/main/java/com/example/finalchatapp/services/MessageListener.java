package com.example.finalchatapp.services;

import android.content.Context;
import android.util.Log;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.MetadataChanges;
import com.google.firebase.firestore.Query;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Service to listen for incoming messages and show notifications in real-time
 */
public class MessageListener {
    private static final String TAG = "MessageListener";

    // Keep track of active listeners to prevent duplication
    private static final Map<String, ListenerRegistration> activeListeners = new HashMap<>();

    // Store IDs of messages we've already processed
    private static final Set<String> processedMessageIds = new HashSet<>();

    // Cache user names to avoid frequent Firestore queries
    private static final Map<String, String> userCache = new HashMap<>();

    /**
     * Start listening for new messages for the current user
     */
    public static void startMessageListeners(Context context) {
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser == null) {
            Log.d(TAG, "Cannot start listeners: User not logged in");
            return;
        }

        String currentUserId = currentUser.getUid();
        Log.d(TAG, "Starting message listeners for user: " + currentUserId);

        // First, get all the user's chats
        FirebaseFirestore.getInstance()
                .collection("users")
                .document(currentUserId)
                .collection("chats")
                .get()
                .addOnSuccessListener(chatSnapshots -> {
                    // Setup a listener for each chat
                    for (int i = 0; i < chatSnapshots.size(); i++) {
                        String otherUserId = chatSnapshots.getDocuments().get(i).getId();
                        setupChatListener(context, currentUserId, otherUserId);
                    }

                    // Also listen for new chats
                    setupNewChatsListener(context, currentUserId);
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Error fetching user's chats: " + e.getMessage());
                });
    }

    /**
     * Listen for new chats being created
     */
    private static void setupNewChatsListener(Context context, String currentUserId) {
        // Already have a chat listener?
        if (activeListeners.containsKey("new_chats")) {
            Log.d(TAG, "New chats listener already active");
            return;
        }

        Log.d(TAG, "Setting up new chats listener");

        // Listen for changes to the user's chats collection
        ListenerRegistration registration = FirebaseFirestore.getInstance()
                .collection("users")
                .document(currentUserId)
                .collection("chats")
                .addSnapshotListener(MetadataChanges.INCLUDE, (snapshots, e) -> {
                    if (e != null) {
                        Log.e(TAG, "Listen for new chats failed: ", e);
                        return;
                    }

                    if (snapshots == null) return;

                    // Look for new chats being added
                    for (DocumentChange dc : snapshots.getDocumentChanges()) {
                        if (dc.getType() == DocumentChange.Type.ADDED) {
                            String otherUserId = dc.getDocument().getId();
                            Log.d(TAG, "New chat detected with user: " + otherUserId);

                            // Set up a listener for this new chat
                            setupChatListener(context, currentUserId, otherUserId);
                        }
                    }
                });

        // Store the registration so we can stop listening later if needed
        activeListeners.put("new_chats", registration);
    }

    /**
     * Setup a listener for messages in a specific chat
     */
    private static void setupChatListener(Context context, String currentUserId, String otherUserId) {
        // Generate a unique key for this chat listener
        String listenerKey = "chat_" + currentUserId + "_" + otherUserId;

        // Check if we already have a listener for this chat
        if (activeListeners.containsKey(listenerKey)) {
            Log.d(TAG, "Chat listener already exists for: " + otherUserId);
            return;
        }

        Log.d(TAG, "Setting up message listener for chat with: " + otherUserId);

        // Determine the chat ID using both user IDs
        String chatId;
        if (currentUserId.compareTo(otherUserId) < 0) {
            chatId = currentUserId + "_" + otherUserId;
        } else {
            chatId = otherUserId + "_" + currentUserId;
        }

        // Create a listener for new messages
        ListenerRegistration registration = FirebaseFirestore.getInstance()
                .collection("chats")
                .document(chatId)
                .collection("messages")
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .limit(20)  // Only listen to the most recent messages
                .addSnapshotListener(MetadataChanges.INCLUDE, (snapshots, e) -> {
                    if (e != null) {
                        Log.e(TAG, "Listen for messages failed: ", e);
                        return;
                    }

                    if (snapshots == null || snapshots.isEmpty()) {
                        return;
                    }

                    // Process new messages
                    for (DocumentChange dc : snapshots.getDocumentChanges()) {
                        if (dc.getType() == DocumentChange.Type.ADDED) {
                            // Extract message data
                            String messageId = dc.getDocument().getId();
                            String senderId = dc.getDocument().getString("senderId");
                            String receiverId = dc.getDocument().getString("receiverId");
                            String content = dc.getDocument().getString("content");

                            // Skip if we've already processed this message
                            if (processedMessageIds.contains(messageId)) {
                                continue;
                            }

                            // Add to processed set
                            processedMessageIds.add(messageId);

                            // Only notify for messages sent TO current user FROM other user
                            if (senderId != null && senderId.equals(otherUserId) &&
                                    receiverId != null && receiverId.equals(currentUserId)) {

                                Log.d(TAG, "New message detected from " + otherUserId + ": " + content);

                                // Get username from cache or from Firestore
                                if (userCache.containsKey(otherUserId)) {
                                    // Use cached username
                                    String username = userCache.get(otherUserId);
                                    NotificationService.showDirectNotification(context, username, content, otherUserId);
                                } else {
                                    // Fetch username from Firestore
                                    FirebaseFirestore.getInstance()
                                            .collection("users")
                                            .document(otherUserId)
                                            .get()
                                            .addOnSuccessListener(userDoc -> {
                                                String username = userDoc.getString("username");
                                                if (username == null) username = "User " + otherUserId.substring(0, 5);

                                                // Cache username
                                                userCache.put(otherUserId, username);

                                                // Show notification
                                                NotificationService.showDirectNotification(context, username, content, otherUserId);
                                            })
                                            .addOnFailureListener(fetchError -> {
                                                // Show notification with generic name
                                                NotificationService.showDirectNotification(context, "New message", content, otherUserId);
                                            });
                                }
                            }
                        }
                    }
                });

        // Store the registration
        activeListeners.put(listenerKey, registration);
    }

    /**
     * Stop all active message listeners
     */
    public static void stopAllListeners() {
        Log.d(TAG, "Stopping all message listeners: " + activeListeners.size());

        for (ListenerRegistration registration : activeListeners.values()) {
            registration.remove();
        }

        activeListeners.clear();
    }

    /**
     * Clean up resources to prevent memory leaks
     */
    public static void cleanup() {
        stopAllListeners();
        processedMessageIds.clear();
        userCache.clear();
    }
}